from train_test import train_test

if __name__ == "__main__":
    data_folder = './DATA'
    view_list = [1, 2, 3]
    num_class = 5  # Define this based on your dataset
    lr_e_pretrain = 0.001
    lr_e = 0.001
    lr_c = 0.001
    num_epoch_pretrain = 500
    num_epoch = 1000
    theta_smooth = 0.1
    theta_degree = 0.1
    theta_sparsity = 0.1
    neta = 0.5
    reg = 0.01

    train_test(data_folder, view_list, num_class,
               lr_e_pretrain, lr_e, lr_c,
               num_epoch_pretrain, num_epoch,
               theta_smooth, theta_degree, theta_sparsity,
               neta, reg)
